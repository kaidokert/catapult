
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.3'
version = '1.11.3'
full_version = '1.11.3'
git_revision = 'bfc9a059c48c57c4ef20bebe88d6f6ce363d1464'
release = True

if not release:
    version = full_version
